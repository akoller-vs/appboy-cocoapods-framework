#import <UIKit/UIKit.h>

@interface ABKInAppMessageWindow : UIWindow

@property BOOL catchClicksOutsideInAppMessage;

@end
