#import <Foundation/Foundation.h>

@interface ABKInAppMessageHTMLJSInterface : NSObject

+ (NSString *)getJSInterface;

@end
